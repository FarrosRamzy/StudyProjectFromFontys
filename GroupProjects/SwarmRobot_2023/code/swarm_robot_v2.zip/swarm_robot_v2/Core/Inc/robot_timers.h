/*
 * robot_timers.h
 *
 *  Created on: Nov 15, 2023
 *      Author: farro
 */

#ifndef INC_ROBOT_TIMERS_H_
#define INC_ROBOT_TIMERS_H_

#include "main.h"

void Timer2_Init(void);
void Timer3_Init(void);
void Timer4_Init(void);

void Channel3_Timer3_Init(void);
void Channel4_Timer3_Init(void);

#endif /* INC_ROBOT_TIMERS_H_ */
